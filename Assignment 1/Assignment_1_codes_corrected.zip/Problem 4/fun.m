function f = fun(u,t,lambda)

f = -lambda*sinh(u - cos(t-1));

end