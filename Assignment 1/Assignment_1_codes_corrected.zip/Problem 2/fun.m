function f = fun(x)

f = sqrt(2 + cos(x)^3)*exp(sin(x));

end

