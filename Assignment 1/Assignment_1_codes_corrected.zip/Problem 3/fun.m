function f = fun(x, alpha, beta, s)

f = x - alpha + beta*sinh(x - cos(s-1));

end